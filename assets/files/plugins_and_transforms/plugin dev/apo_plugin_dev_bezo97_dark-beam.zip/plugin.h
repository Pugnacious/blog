#pragma once

#ifdef APO_NOVARIABLES
	#include "plugin_novar.h"
#else
	#include "plugin_var.h"
#endif
