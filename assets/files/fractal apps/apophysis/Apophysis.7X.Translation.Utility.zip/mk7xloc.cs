﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Xml.Linq;

[assembly: AssemblyTitle("ApoTrans")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("ApoTrans")]
[assembly: AssemblyCopyright("Copyright ©  2012")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]

partial class TranslationForm : Form
{
    private System.ComponentModel.IContainer components = null;
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    #region Designer
    private void InitializeComponent()
    {
        System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
        System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
        this.MainMenu = new System.Windows.Forms.MenuStrip();
        this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
        this.updateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
        this.openSectionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.saveSectionAsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripSeparator();
        this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.saveAsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
        this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.FindPascal = new System.Windows.Forms.OpenFileDialog();
        this.FindXml = new System.Windows.Forms.OpenFileDialog();
        this.SaveXml = new System.Windows.Forms.SaveFileDialog();
        this.panel1 = new System.Windows.Forms.Panel();
        this.groupBox3 = new System.Windows.Forms.GroupBox();
        this.txtCulture = new System.Windows.Forms.TextBox();
        this.cbCulture = new System.Windows.Forms.ComboBox();
        this.groupBox2 = new System.Windows.Forms.GroupBox();
        this.label1 = new System.Windows.Forms.Label();
        this.txtAuthor = new System.Windows.Forms.TextBox();
        this.groupBox1 = new System.Windows.Forms.GroupBox();
        this.label3 = new System.Windows.Forms.Label();
        this.label2 = new System.Windows.Forms.Label();
        this.txtLocalName = new System.Windows.Forms.TextBox();
        this.txtName = new System.Windows.Forms.TextBox();
        this.Sections = new System.Windows.Forms.TreeView();
        this.Splitter = new System.Windows.Forms.Splitter();
        this.panel2 = new System.Windows.Forms.Panel();
        this.Data = new System.Windows.Forms.DataGridView();
        this.cName = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.cValue = new System.Windows.Forms.DataGridViewTextBoxColumn();
        this.MainMenu.SuspendLayout();
        this.panel1.SuspendLayout();
        this.groupBox3.SuspendLayout();
        this.groupBox2.SuspendLayout();
        this.groupBox1.SuspendLayout();
        this.panel2.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)(this.Data)).BeginInit();
        this.SuspendLayout();
        // 
        // MainMenu
        // 
        this.MainMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
        this.MainMenu.Location = new System.Drawing.Point(0, 0);
        this.MainMenu.Name = "MainMenu";
        this.MainMenu.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
        this.MainMenu.Size = new System.Drawing.Size(991, 24);
        this.MainMenu.TabIndex = 2;
        // 
        // fileToolStripMenuItem
        // 
        this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.openToolStripMenuItem,
            this.toolStripMenuItem1,
            this.updateToolStripMenuItem,
            this.toolStripMenuItem3,
            this.openSectionToolStripMenuItem,
            this.saveSectionAsToolStripMenuItem,
            this.toolStripMenuItem4,
            this.saveToolStripMenuItem,
            this.saveAsToolStripMenuItem,
            this.toolStripMenuItem2,
            this.exitToolStripMenuItem});
        this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
        this.fileToolStripMenuItem.Size = new System.Drawing.Size(35, 20);
        this.fileToolStripMenuItem.Text = "File";
        // 
        // newToolStripMenuItem
        // 
        this.newToolStripMenuItem.Name = "newToolStripMenuItem";
        this.newToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
        this.newToolStripMenuItem.Size = new System.Drawing.Size(247, 22);
        this.newToolStripMenuItem.Text = "Create from source code...";
        this.newToolStripMenuItem.Click += new System.EventHandler(this.mnuCreate_Click);
        // 
        // openToolStripMenuItem
        // 
        this.openToolStripMenuItem.Name = "openToolStripMenuItem";
        this.openToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
        this.openToolStripMenuItem.Size = new System.Drawing.Size(247, 22);
        this.openToolStripMenuItem.Text = "Open language file...";
        this.openToolStripMenuItem.Click += new System.EventHandler(this.mnuOpen_Click);
        // 
        // toolStripMenuItem1
        // 
        this.toolStripMenuItem1.Name = "toolStripMenuItem1";
        this.toolStripMenuItem1.Size = new System.Drawing.Size(244, 6);
        // 
        // updateToolStripMenuItem
        // 
        this.updateToolStripMenuItem.Enabled = false;
        this.updateToolStripMenuItem.Name = "updateToolStripMenuItem";
        this.updateToolStripMenuItem.Size = new System.Drawing.Size(247, 22);
        this.updateToolStripMenuItem.Text = "Refresh with newest source code...";
        this.updateToolStripMenuItem.Click += new System.EventHandler(this.mnuUpdate_Click);
        // 
        // toolStripMenuItem3
        // 
        this.toolStripMenuItem3.Name = "toolStripMenuItem3";
        this.toolStripMenuItem3.Size = new System.Drawing.Size(244, 6);
        // 
        // openSectionToolStripMenuItem
        // 
        this.openSectionToolStripMenuItem.Name = "openSectionToolStripMenuItem";
        this.openSectionToolStripMenuItem.Size = new System.Drawing.Size(247, 22);
        this.openSectionToolStripMenuItem.Text = "Insert partial language file...";
        this.openSectionToolStripMenuItem.Click += new System.EventHandler(this.mnuOpenSection_Click);
        // 
        // saveSectionAsToolStripMenuItem
        // 
        this.saveSectionAsToolStripMenuItem.Name = "saveSectionAsToolStripMenuItem";
        this.saveSectionAsToolStripMenuItem.Size = new System.Drawing.Size(247, 22);
        this.saveSectionAsToolStripMenuItem.Text = "Save currently shown strings...";
        this.saveSectionAsToolStripMenuItem.Click += new System.EventHandler(this.mnuSaveSection_Click);
        // 
        // toolStripMenuItem4
        // 
        this.toolStripMenuItem4.Name = "toolStripMenuItem4";
        this.toolStripMenuItem4.Size = new System.Drawing.Size(244, 6);
        // 
        // saveToolStripMenuItem
        // 
        this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
        this.saveToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
        this.saveToolStripMenuItem.Size = new System.Drawing.Size(247, 22);
        this.saveToolStripMenuItem.Text = "Save language file";
        this.saveToolStripMenuItem.Click += new System.EventHandler(this.mnuSave_Click);
        // 
        // saveAsToolStripMenuItem
        // 
        this.saveAsToolStripMenuItem.Name = "saveAsToolStripMenuItem";
        this.saveAsToolStripMenuItem.Size = new System.Drawing.Size(247, 22);
        this.saveAsToolStripMenuItem.Text = "Save language file as...";
        this.saveAsToolStripMenuItem.Click += new System.EventHandler(this.mnuSaveAs_Click);
        // 
        // toolStripMenuItem2
        // 
        this.toolStripMenuItem2.Name = "toolStripMenuItem2";
        this.toolStripMenuItem2.Size = new System.Drawing.Size(244, 6);
        // 
        // exitToolStripMenuItem
        // 
        this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
        this.exitToolStripMenuItem.Size = new System.Drawing.Size(247, 22);
        this.exitToolStripMenuItem.Text = "Exit";
        this.exitToolStripMenuItem.Click += new System.EventHandler(this.mnuExit_Click);
        // 
        // FindPascal
        // 
        this.FindPascal.FileName = "Translation.pas";
        this.FindPascal.Filter = "Translation Source Code File (Translation.pas)|Translation.pas|Pascal Source Code" +
            " Files (*.pas)|*.pas|All Files (*.*)|*.*";
        this.FindPascal.Title = "Find Translation.pas";
        // 
        // FindXml
        // 
        this.FindXml.Filter = "Language Files (*.xml)|*.xml|All Files (*.*)|*.*";
        this.FindXml.Title = "Open Language File...";
        // 
        // SaveXml
        // 
        this.SaveXml.Filter = "Language Files (*.xml)|*.xml|All Files (*.*)|*.*";
        this.SaveXml.Title = "Save language...";
        // 
        // panel1
        // 
        this.panel1.Controls.Add(this.groupBox3);
        this.panel1.Controls.Add(this.groupBox2);
        this.panel1.Controls.Add(this.groupBox1);
        this.panel1.Controls.Add(this.Sections);
        this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
        this.panel1.Location = new System.Drawing.Point(0, 24);
        this.panel1.MaximumSize = new System.Drawing.Size(600, 0);
        this.panel1.MinimumSize = new System.Drawing.Size(200, 0);
        this.panel1.Name = "panel1";
        this.panel1.Size = new System.Drawing.Size(320, 562);
        this.panel1.TabIndex = 6;
        // 
        // groupBox3
        // 
        this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                    | System.Windows.Forms.AnchorStyles.Right)));
        this.groupBox3.Controls.Add(this.txtCulture);
        this.groupBox3.Controls.Add(this.cbCulture);
        this.groupBox3.Location = new System.Drawing.Point(6, 148);
        this.groupBox3.Name = "groupBox3";
        this.groupBox3.Size = new System.Drawing.Size(307, 52);
        this.groupBox3.TabIndex = 6;
        this.groupBox3.TabStop = false;
        this.groupBox3.Text = "Culture code";
        // 
        // txtCulture
        // 
        this.txtCulture.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
        this.txtCulture.Enabled = false;
        this.txtCulture.Font = new System.Drawing.Font("Courier New", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.txtCulture.Location = new System.Drawing.Point(256, 23);
        this.txtCulture.Name = "txtCulture";
        this.txtCulture.ReadOnly = true;
        this.txtCulture.Size = new System.Drawing.Size(45, 21);
        this.txtCulture.TabIndex = 7;
        // 
        // cbCulture
        // 
        this.cbCulture.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                    | System.Windows.Forms.AnchorStyles.Right)));
        this.cbCulture.Enabled = false;
        this.cbCulture.Font = new System.Drawing.Font("Courier New", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.cbCulture.FormattingEnabled = true;
        this.cbCulture.Location = new System.Drawing.Point(9, 23);
        this.cbCulture.Name = "cbCulture";
        this.cbCulture.Size = new System.Drawing.Size(241, 23);
        this.cbCulture.TabIndex = 3;
        this.cbCulture.SelectedIndexChanged += new System.EventHandler(this.Culture_Changed);
        // 
        // groupBox2
        // 
        this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                    | System.Windows.Forms.AnchorStyles.Right)));
        this.groupBox2.Controls.Add(this.label1);
        this.groupBox2.Controls.Add(this.txtAuthor);
        this.groupBox2.Location = new System.Drawing.Point(6, 8);
        this.groupBox2.Name = "groupBox2";
        this.groupBox2.Size = new System.Drawing.Size(308, 46);
        this.groupBox2.TabIndex = 5;
        this.groupBox2.TabStop = false;
        this.groupBox2.Text = "Credits";
        // 
        // label1
        // 
        this.label1.AutoSize = true;
        this.label1.Location = new System.Drawing.Point(6, 22);
        this.label1.Name = "label1";
        this.label1.Size = new System.Drawing.Size(38, 13);
        this.label1.TabIndex = 7;
        this.label1.Text = "Author";
        // 
        // txtAuthor
        // 
        this.txtAuthor.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                    | System.Windows.Forms.AnchorStyles.Right)));
        this.txtAuthor.Enabled = false;
        this.txtAuthor.Font = new System.Drawing.Font("Courier New", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.txtAuthor.Location = new System.Drawing.Point(64, 19);
        this.txtAuthor.Name = "txtAuthor";
        this.txtAuthor.Size = new System.Drawing.Size(238, 21);
        this.txtAuthor.TabIndex = 0;
        this.txtAuthor.TextChanged += new System.EventHandler(this.Metadata_Changed);
        // 
        // groupBox1
        // 
        this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                    | System.Windows.Forms.AnchorStyles.Right)));
        this.groupBox1.Controls.Add(this.label3);
        this.groupBox1.Controls.Add(this.label2);
        this.groupBox1.Controls.Add(this.txtLocalName);
        this.groupBox1.Controls.Add(this.txtName);
        this.groupBox1.Location = new System.Drawing.Point(6, 64);
        this.groupBox1.Name = "groupBox1";
        this.groupBox1.Size = new System.Drawing.Size(308, 78);
        this.groupBox1.TabIndex = 4;
        this.groupBox1.TabStop = false;
        this.groupBox1.Text = "Language name";
        // 
        // label3
        // 
        this.label3.AutoSize = true;
        this.label3.Location = new System.Drawing.Point(6, 48);
        this.label3.Name = "label3";
        this.label3.Size = new System.Drawing.Size(52, 13);
        this.label3.TabIndex = 8;
        this.label3.Text = "Localized";
        // 
        // label2
        // 
        this.label2.AutoSize = true;
        this.label2.Location = new System.Drawing.Point(6, 22);
        this.label2.Name = "label2";
        this.label2.Size = new System.Drawing.Size(41, 13);
        this.label2.TabIndex = 7;
        this.label2.Text = "English";
        // 
        // txtLocalName
        // 
        this.txtLocalName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                    | System.Windows.Forms.AnchorStyles.Right)));
        this.txtLocalName.Enabled = false;
        this.txtLocalName.Font = new System.Drawing.Font("Courier New", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.txtLocalName.Location = new System.Drawing.Point(64, 45);
        this.txtLocalName.Name = "txtLocalName";
        this.txtLocalName.Size = new System.Drawing.Size(238, 21);
        this.txtLocalName.TabIndex = 2;
        this.txtLocalName.TextChanged += new System.EventHandler(this.Metadata_Changed);
        // 
        // txtName
        // 
        this.txtName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                    | System.Windows.Forms.AnchorStyles.Right)));
        this.txtName.Enabled = false;
        this.txtName.Font = new System.Drawing.Font("Courier New", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.txtName.Location = new System.Drawing.Point(64, 19);
        this.txtName.Name = "txtName";
        this.txtName.Size = new System.Drawing.Size(238, 21);
        this.txtName.TabIndex = 1;
        this.txtName.TextChanged += new System.EventHandler(this.Metadata_Changed);
        // 
        // Sections
        // 
        this.Sections.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                    | System.Windows.Forms.AnchorStyles.Left)
                    | System.Windows.Forms.AnchorStyles.Right)));
        this.Sections.Enabled = false;
        this.Sections.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.Sections.Location = new System.Drawing.Point(0, 204);
        this.Sections.MinimumSize = new System.Drawing.Size(100, 4);
        this.Sections.Name = "Sections";
        this.Sections.Size = new System.Drawing.Size(320, 4292);
        this.Sections.TabIndex = 4;
        this.Sections.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.Sections_AfterSelect);
        // 
        // Splitter
        // 
        this.Splitter.Location = new System.Drawing.Point(320, 24);
        this.Splitter.Name = "Splitter";
        this.Splitter.Size = new System.Drawing.Size(5, 562);
        this.Splitter.TabIndex = 7;
        this.Splitter.TabStop = false;
        // 
        // panel2
        // 
        this.panel2.Controls.Add(this.Data);
        this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
        this.panel2.Location = new System.Drawing.Point(325, 24);
        this.panel2.Name = "panel2";
        this.panel2.Size = new System.Drawing.Size(666, 562);
        this.panel2.TabIndex = 8;
        // 
        // Data
        // 
        this.Data.AllowUserToAddRows = false;
        this.Data.AllowUserToDeleteRows = false;
        this.Data.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
        this.Data.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.cName,
            this.cValue});
        this.Data.Dock = System.Windows.Forms.DockStyle.Fill;
        this.Data.Enabled = false;
        this.Data.Location = new System.Drawing.Point(0, 0);
        this.Data.MinimumSize = new System.Drawing.Size(300, 0);
        this.Data.MultiSelect = false;
        this.Data.Name = "Data";
        this.Data.RowHeadersVisible = false;
        this.Data.Size = new System.Drawing.Size(666, 562);
        this.Data.TabIndex = 5;
        this.Data.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Data_CellClick);
        this.Data.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.Data_CellEnter);
        this.Data.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.Data_CellValueChanged);
        // 
        // cName
        // 
        dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
        dataGridViewCellStyle1.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
        this.cName.DefaultCellStyle = dataGridViewCellStyle1;
        this.cName.HeaderText = "Name";
        this.cName.Name = "cName";
        this.cName.ReadOnly = true;
        this.cName.Width = 300;
        // 
        // cValue
        // 
        this.cValue.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
        dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
        dataGridViewCellStyle2.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
        this.cValue.DefaultCellStyle = dataGridViewCellStyle2;
        this.cValue.HeaderText = "Value";
        this.cValue.Name = "cValue";
        // 
        // TranslationForm
        // 
        this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        this.ClientSize = new System.Drawing.Size(991, 586);
        this.Controls.Add(this.panel2);
        this.Controls.Add(this.Splitter);
        this.Controls.Add(this.panel1);
        this.Controls.Add(this.MainMenu);
        this.MainMenuStrip = this.MainMenu;
        this.MinimumSize = new System.Drawing.Size(800, 600);
        this.Name = "TranslationForm";
        this.Text = "Apophysis Translation Editor";
        this.MainMenu.ResumeLayout(false);
        this.MainMenu.PerformLayout();
        this.panel1.ResumeLayout(false);
        this.groupBox3.ResumeLayout(false);
        this.groupBox3.PerformLayout();
        this.groupBox2.ResumeLayout(false);
        this.groupBox2.PerformLayout();
        this.groupBox1.ResumeLayout(false);
        this.groupBox1.PerformLayout();
        this.panel2.ResumeLayout(false);
        ((System.ComponentModel.ISupportInitialize)(this.Data)).EndInit();
        this.ResumeLayout(false);
        this.PerformLayout();
        this.Icon = new System.Drawing.Icon(
            Assembly.GetExecutingAssembly().GetManifestResourceStream("Apophysis.Translation.ico"));
    }
    #endregion

    private System.Windows.Forms.MenuStrip MainMenu;
    private System.Windows.Forms.OpenFileDialog FindPascal;
    private System.Windows.Forms.OpenFileDialog FindXml;
    private System.Windows.Forms.SaveFileDialog SaveXml;
    private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
    private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
    private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem saveAsToolStripMenuItem;
    private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
    private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
    private System.Windows.Forms.Panel panel1;
    private System.Windows.Forms.TreeView Sections;
    private System.Windows.Forms.Splitter Splitter;
    private System.Windows.Forms.Panel panel2;
    private System.Windows.Forms.DataGridView Data;
    private System.Windows.Forms.DataGridViewTextBoxColumn cName;
    private System.Windows.Forms.DataGridViewTextBoxColumn cValue;
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.TextBox txtLocalName;
    private System.Windows.Forms.TextBox txtName;
    private System.Windows.Forms.GroupBox groupBox2;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.TextBox txtAuthor;
    private System.Windows.Forms.GroupBox groupBox3;
    private System.Windows.Forms.ComboBox cbCulture;
    private System.Windows.Forms.TextBox txtCulture;
    private System.Windows.Forms.ToolStripMenuItem updateToolStripMenuItem;
    private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
    private System.Windows.Forms.ToolStripMenuItem openSectionToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem saveSectionAsToolStripMenuItem;
    private System.Windows.Forms.ToolStripSeparator toolStripMenuItem4;

    class Translation
    {
        struct RawToken
        {
            string[] segments;

            public RawToken(string raw)
            {
                if (string.IsNullOrEmpty(raw)) throw new ArgumentNullException("raw");
                segments = raw.Split('-');
            }

            public string[] Path
            {
                get
                {
                    segments = segments ?? new string[] { };
                    if (segments.Length < 2) return new string[] { };

                    var list = new List<string>(segments);
                    list.RemoveAt(list.Count - 1);
                    return list.ToArray();
                }
                set
                {
                    value = value ?? new string[] { };
                    foreach (var item in value)
                        if (item.Contains("-")) throw new ArgumentException("Segment can't contain '-'", "value");
                    string name = this.Name;
                    var list = new List<string>(value);
                    list.Add(name);
                    segments = list.ToArray();
                }
            }
            public string Name
            {
                get
                {
                    segments = segments ?? new string[] { };
                    if (segments.Length < 1) return string.Empty;
                    return segments[segments.Length - 1];
                }
                set
                {
                    if (string.IsNullOrEmpty(value)) throw new ArgumentNullException("value");
                    if (value.Contains("-")) throw new ArgumentException("Name can't contain '-'", "value");
                    var list = new List<string>(this.Path);
                    list.Add(value);
                    segments = list.ToArray();
                }
            }
            public string RawString
            {
                get
                {
                    segments = segments ?? new string[] { };
                    return string.Join("-", segments);
                }
                set
                {
                    segments = segments ?? new string[] { };
                    if (string.IsNullOrEmpty(value)) throw new ArgumentNullException("value");
                    segments = value.Split('-');
                }
            }

            public override string ToString()
            {
                return RawString;
            }
            public override bool Equals(object obj)
            {
                return (obj ?? new object()).GetHashCode() == this.GetHashCode(); ;
            }
            public override int GetHashCode()
            {
                return this.ToString().GetHashCode();
            }
        }

        Dictionary<String, Translation> sections;
        Dictionary<String, String> strings;
        String baseName;

        private Translation(String baseName, Dictionary<RawToken, String> items)
        {
            this.baseName = baseName;
            this.sections = GetSections(items);
            this.strings = GetStrings(items);
        }
        private Translation(Translation parent, XElement element)
        {
            var pbn = parent == null ? "" : parent.baseName;

            if (element.Name == "stringtable")
            {
                this.Culture = (element.Attribute("culture") ?? new XAttribute("culture", "")).Value;
                this.Name = (element.Attribute("title") ?? new XAttribute("title", "")).Value;
                this.LocalName = (element.Attribute("localized-title") ?? new XAttribute("localized-title", "")).Value;
                this.Author = (element.Attribute("author") ?? new XAttribute("author", "")).Value;

                baseName = "";
            }
            else baseName = (pbn + "-" + element.Name.ToString()).TrimStart('-');

            strings = new Dictionary<string, string>();
            sections = new Dictionary<string, Translation>();

            foreach (var child in element.Elements())
            {
                if (child.Elements().Count() == 0) strings.Add(child.Name.ToString(), child.Value.ToString());
                else sections.Add(child.Name.ToString(), new Translation(this, child)
                {
                    Culture = this.Culture,
                    Name = this.Name,
                    LocalName = this.LocalName,
                    Author = this.Author
                });
            }
        }

        public Translation(String pascalPath)
        {
            string p_str = File.ReadAllText(pascalPath);
            const string p_regex = @"^\s*Add\('(.*?)',\s*'(.*)'\);\s*$";

            Dictionary<RawToken, String> items = new Dictionary<RawToken, string>();
            foreach (Match match in Regex.Matches(p_str, p_regex, RegexOptions.Multiline))
            {
                var token = new RawToken(match.Groups[1].Value);
                if (!items.ContainsKey(token)) items.Add(token, match.Groups[2].Value);
            }

            sections = GetSections(items);
            strings = GetStrings(items);
            baseName = "";
        }
        public Translation(XElement element) : this(null, element) { }

        public string Culture
        {
            get;
            set;
        }
        public string Name
        {
            get;
            set;
        }
        public string LocalName
        {
            get;
            set;
        }
        public string Author
        {
            get;
            set;
        }

        private Dictionary<String, Translation> GetSections(Dictionary<RawToken, String> items)
        {
            Dictionary<String, Dictionary<RawToken, String>> new_items =
                new Dictionary<String, Dictionary<RawToken, String>>();
            foreach (var key in items.Keys)
                if (key.Path.Length > 0)
                {
                    var n_key = key;
                    var list = new List<string>(key.Path);
                    var tld = list[0];
                    var dic = new_items.ContainsKey(tld) ?
                        new_items[tld] : new Dictionary<RawToken, String>();
                    if (!new_items.ContainsKey(tld)) new_items.Add(tld, dic);
                    list.RemoveAt(0); n_key.Path = list.ToArray();
                    dic.Add(n_key, items[key]);
                }
            Dictionary<String, Translation> result = new Dictionary<String, Translation>();
            foreach (var key in new_items.Keys)
                result.Add(key, new Translation((baseName + "-" + key).TrimStart('-'), new_items[key]));
            return result;
        }
        private Dictionary<String, String> GetStrings(Dictionary<RawToken, String> items)
        {
            Dictionary<String, String> result = new Dictionary<String, String>();
            foreach (var key in items.Keys)
                if (key.Path.Length == 0)
                    result.Add(key.Name, items[key]);
            return result;
        }

        public Dictionary<String, Translation> Sections
        {
            get { return sections; }
        }
        public ReadOnlyCollection<String> Keys
        {
            get
            {
                string[] stringKeys = new string[strings.Keys.Count];
                strings.Keys.CopyTo(stringKeys, 0);
                return new ReadOnlyCollection<String>(new List<String>(stringKeys));
            }
        }
        public String this[String key]
        {
            get
            {
                return strings[key];
            }
            set
            {
                strings[key] = value;
            }
        }
        public String BaseName
        {
            get { return baseName; }
        }

        public XElement GetXml(String name)
        {
            XElement doc = new XElement(XName.Get(name));

            foreach (var item in this.strings.Keys)
                doc.Add(new XElement(XName.Get(item), strings[item]));
            foreach (var item in this.sections.Keys)
                doc.Add(sections[item].GetXml(item));

            return doc;
        }
        public void SaveXml(String path)
        {
            XElement root = GetXml("stringtable");

            root.Add(new XAttribute("culture", this.Culture ?? ""));
            root.Add(new XAttribute("title", this.Name ?? ""));
            root.Add(new XAttribute("localized-title", this.LocalName ?? ""));
            root.Add(new XAttribute("author", this.Author ?? ""));

            XDocument doc = new XDocument(root);
            doc.Declaration = new XDeclaration("1.0", "utf-8", "yes");

            doc.Save(path, SaveOptions.None);
        }

        public ReadOnlyCollection<String> AllKeys
        {
            get
            {
                var list = new List<String>();
                list.AddRange(this.Keys.Select((x) => (this.BaseName + "-" + x).Trim('-')));
                foreach (var section in this.Sections.Keys)
                    list.AddRange(this.Sections[section].AllKeys);
                return new ReadOnlyCollection<String>(list);
            }
        }

        public IList<String> LoadFrom(Translation source)
        {
            var missing = new List<String>();
            foreach (var key in this.Keys)
            {
                if (source.strings.ContainsKey(key))
                    this[key] = source[key];
                else missing.Add((this.BaseName + "-" + key).Trim('-'));
            }
            foreach (var key in this.sections.Keys)
            {
                if (source.sections.ContainsKey(key))
                    missing.AddRange(this.Sections[key].LoadFrom(source.Sections[key]));
                else missing.AddRange(this.Sections[key].AllKeys);
            }
            return missing;
        }
    }


    private Translation trans;
    private Boolean changed;
    private String location;
    private Boolean saveOK;
    private Boolean mdChanged;

    public TranslationForm()
    {
        InitializeComponent();

        foreach (var culture in CultureInfo.GetCultures(CultureTypes.AllCultures).OrderBy((x) => x.Name))
            cbCulture.Items.Add(culture);
    }

    private string NameOf(CultureInfo c)
    {
        if (c.Name.Length == 2)
            return c.Name.ToLower() + "-" + c.Name.ToUpper();
        else return c.Name;
    }

    private void mnuCreate_Click(object sender, EventArgs e)
    {
        if (changed && trans != null)
        {
            var result = MessageBox.Show("The translation file has been changed. " +
                "Do you want to save it before creating a new one?",
                this.Text, MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            switch (result)
            {
                case System.Windows.Forms.DialogResult.Yes:
                    saveOK = false;
                    mnuSave_Click(sender, e);
                    if (!saveOK) return;
                    else break;
                case System.Windows.Forms.DialogResult.No: break;
                default: return;
            }
        }
        if (FindPascal.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;

        Sections.Nodes.Clear();
        Data.Rows.Clear();

        #if DEBUG
        trans = new Translation(FindPascal.FileName);
        #else
        try
        {
            trans = new Translation(FindPascal.FileName);
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            trans = null;

        }
        #endif

        UpdateMenu();

        if (trans != null)
        {
            FillTree(Sections.Nodes.Add("<root>"), trans);
            Sections.SelectedNode = Sections.Nodes[0];

            changed = false;
            location = null;
        }
    }
    private void mnuOpen_Click(object sender, EventArgs e)
    {
        if (changed && trans != null)
        {
            var result = MessageBox.Show("The translation file has been changed. " +
                "Do you want to save it before opening another file?",
                this.Text, MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            switch (result)
            {
                case System.Windows.Forms.DialogResult.Yes:
                    saveOK = false;
                    mnuSave_Click(sender, e);
                    if (!saveOK) return;
                    else break;
                case System.Windows.Forms.DialogResult.No: break;
                default: return;
            }
        }

        if (FindXml.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;

        Sections.Nodes.Clear();
        Data.Rows.Clear();

        #if DEBUG
        trans = new Translation(XDocument.Load(FindXml.FileName).Element("stringtable"));
        #else
        try
        {
            trans = new Translation(XDocument.Load(FindXml.FileName).Element("stringtable"));
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            trans = null;

        }
        #endif

        UpdateMenu();

        if (trans != null)
        {
            FillTree(Sections.Nodes.Add("<root>"), trans);
            Sections.SelectedNode = Sections.Nodes[0];

            changed = false;
            location = FindXml.FileName;
        }
    }
    private void mnuUpdate_Click(object sender, EventArgs e)
    {
        if (trans == null) return;
        if (FindPascal.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;

        var source = trans;
        var target = (Translation)null;

        #if DEBUG
        target = new Translation(FindPascal.FileName);
        #else
        try
        {
            target = new Translation(FindPascal.FileName);
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }
        #endif

        var missing = target.LoadFrom(source);

        target.Name = source.Name ?? "";
        target.LocalName = source.LocalName ?? "";
        target.Author = source.Author ?? "";
        target.Culture = source.Culture ?? "";

        trans = target;

        Sections.Nodes.Clear();

        changed = true;
        UpdateMenu();

        FillTree(Sections.Nodes.Add("<root>"), trans);
        Sections.SelectedNode = Sections.Nodes[0];

        Data.Rows.Clear();

        foreach (var key in missing)
        {
            var i = Data.Rows.Add();
            var n = key.Split('-');

            var translation = target;
            if (n.Length > 1)
            {
                for (int j = 0; j < n.Length - 1; j++)
                    translation = translation.Sections[n[j]];
            }

            Data.Rows[i].Cells[0].Value = key;
            Data.Rows[i].Cells[1].Value = translation[n[n.Length - 1]];
            Data.Rows[i].Cells[1].Tag = translation;
        }
    }
    private void mnuOpenSection_Click(object sender, EventArgs e)
    {
        if (FindXml.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;

        Sections.Nodes.Clear();
        Data.Rows.Clear();

        var source = (Translation)null;

        #if DEBUG
        source = new Translation(XDocument.Load(FindXml.FileName).Element("stringtable"));
        #else
        try
        {
            trans = new Translation(XDocument.Load(FindXml.FileName).Element("stringtable"));
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }
        #endif

        trans.LoadFrom(source);

        changed = true;
        UpdateMenu();
    }
    private void mnuSaveSection_Click(object sender, EventArgs e)
    {
        if (trans == null) return;
        if (SaveXml.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;

        var root = new XElement("stringtable");

        root.Add(new XAttribute("culture", trans.Culture ?? ""));
        root.Add(new XAttribute("title", trans.Name ?? ""));
        root.Add(new XAttribute("localized-title", trans.LocalName ?? ""));
        root.Add(new XAttribute("author", trans.Author ?? ""));

        foreach (DataGridViewRow row in Data.Rows)
        {
            var key = row.Cells[0].Value as string ?? "";
            var value = row.Cells[1].Value as string ?? "";

            var n = key.Split('-');
            var element = root;
            for (int j = 0; j < n.Length; j++)
            {
                var new_element = element.Element(n[j]);
                if (new_element == null)
                {
                    new_element = new XElement(n[j]);
                    element.Add(new_element);
                }
                element = new_element;
            }

            element.SetValue(value);
        }

        XDocument doc = new XDocument(root);
        doc.Declaration = new XDeclaration("1.0", "utf-8", "yes");

        doc.Save(SaveXml.FileName, SaveOptions.None);

    }
    private void mnuSave_Click(object sender, EventArgs e)
    {
        if (trans == null) return;

        if (string.IsNullOrEmpty(location))
        {
            mnuSaveAs_Click(sender, e);
            return;
        }

        bool ok;

        #if DEBUG
        trans.SaveXml(location);
        ok = true;
        #else
        ok = false;
        try
        {
            trans.SaveXml(location);
            ok = true;
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);

        }
        #endif

        if (ok)
        {
            changed = false;
            saveOK = true;
        }
        UpdateMenu();
    }
    private void mnuSaveAs_Click(object sender, EventArgs e)
    {
        if (trans == null) return;
        if (SaveXml.ShowDialog() != System.Windows.Forms.DialogResult.OK) return;

        bool ok = false;

        #if DEBUG
        trans.SaveXml(SaveXml.FileName);
        ok = true;
        #else
        try
        {
            trans.SaveXml(SaveXml.FileName);
            ok = true;
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);

        }
        #endif

        if (ok)
        {
            changed = false;
            location = SaveXml.FileName;
            saveOK = true;
        }

        UpdateMenu();
    }
    private void mnuExit_Click(object sender, EventArgs e)
    {
        if (changed && trans != null)
        {
            var result = MessageBox.Show("The translation file has been changed. " +
                "Do you want to save it before exiting?",
                this.Text, MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            switch (result)
            {
                case System.Windows.Forms.DialogResult.Yes:
                    saveOK = false;
                    mnuSave_Click(sender, e);
                    if (!saveOK) return;
                    else break;
                case System.Windows.Forms.DialogResult.No: break;
                default: return;
            }
        }
        this.Close();
    }

    void FillTree(TreeNode targetNode, Translation translation)
    {
        if (targetNode == null || targetNode.Text == "<root>")
        {
            mdChanged = true;
            txtAuthor.Text = translation.Author;
            txtName.Text = translation.Name;
            txtLocalName.Text = translation.LocalName;
            txtCulture.Text = translation.Culture;

            for (int i = 0; i < cbCulture.Items.Count; i++)
            {
                CultureInfo c = (CultureInfo)cbCulture.Items[i];
                if (NameOf(c).ToLower() == (translation.Culture??"").ToLower())
                {
                    cbCulture.SelectedIndex = i;
                    break;
                }
            }

            mdChanged = false;
        }

        foreach (var section in translation.Sections.Keys)
        {
            if (targetNode == null)
            {
                var node = Sections.Nodes.Add(section);
                node.Tag = translation.Sections[section];
                FillTree(node, translation.Sections[section]);
            }
            else
            {
                var node = targetNode.Nodes.Add(section);
                node.Tag = translation.Sections[section];
                FillTree(node, translation.Sections[section]);
            }
        }

        if (targetNode == null || targetNode.Text == "<root>")
            targetNode.Expand();
    }
    void FillList(Translation translation)
    {
        foreach (var s in translation.Keys)
        {
            var i = Data.Rows.Add();
            Data.Rows[i].Cells[0].Value = translation.BaseName + "-" + s;
            Data.Rows[i].Cells[1].Value = translation[s];
            Data.Rows[i].Cells[1].Tag = translation;
        }

        foreach (var section in translation.Sections.Keys)
            FillList(translation.Sections[section]);
    }
    void UpdateMenu()
    {
        saveAsToolStripMenuItem.Enabled = trans != null;
        saveToolStripMenuItem.Enabled = trans != null && changed;
        updateToolStripMenuItem.Enabled = trans != null;

        txtAuthor.Enabled = cbCulture.Enabled = txtLocalName.Enabled = txtName.Enabled =
            Data.Enabled = Sections.Enabled = txtCulture.Enabled = trans != null;
    }

    private void Sections_AfterSelect(object sender, TreeViewEventArgs e)
    {
        var ltrans = e.Node.Text == "<root>" ? this.trans : (e.Node.Tag as Translation);

        Data.Rows.Clear();
        if (ltrans == null) return;

        FillList(ltrans);
    }
    private void Data_CellClick(object sender, DataGridViewCellEventArgs e)
    {
        if (e.ColumnIndex == 1)
            Data.BeginEdit(true);
    }
    private void Data_CellEnter(object sender, DataGridViewCellEventArgs e)
    {
        Data_CellClick(sender, e);
    }
    private void Data_CellValueChanged(object sender, DataGridViewCellEventArgs e)
    {
        if (e.RowIndex < 0) return;

        var ltrans = Data.Rows[e.RowIndex].Cells[1].Tag as Translation;
        if (ltrans == null) return;

        ltrans[Data.Rows[e.RowIndex].Cells[0].Value as string] = Data.Rows[e.RowIndex].Cells[1].Value as string;
        changed = true;
        UpdateMenu();
    }
    private void Metadata_Changed(object sender, EventArgs e)
    {
        if (mdChanged) return;
        if (trans == null) return;

        trans.Author = txtAuthor.Text;
        trans.Name = txtName.Text;
        trans.LocalName = txtLocalName.Text;

        changed = true;
        UpdateMenu();
    }
    private void Culture_Changed(object sender, EventArgs e)
    {
        if (mdChanged) return;
        if (trans == null) return;

        trans.Culture = NameOf(((CultureInfo)cbCulture.SelectedItem));
        txtCulture.Text = trans.Culture;

        changed = true;
        UpdateMenu();
    }
}

static class Program
{
    [STAThread]
    static void Main()
    {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new TranslationForm());
    }
}