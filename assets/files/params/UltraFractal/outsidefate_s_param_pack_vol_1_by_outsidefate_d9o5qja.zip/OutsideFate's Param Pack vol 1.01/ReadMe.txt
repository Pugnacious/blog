Readme.txt

Hello guys. Misha speaking. I know most of you probably won't end up reading a manuscript like this one in detail, so I'll keep it short. 
So, this is my first actual param pack. I've been sharing my stuff for a while on the chats and through direct interactions with other fractalers on dA, so it probably doesn't really count. But here it is.
I just wanted to mention some quirks about the parameters and stuff I feel like talking about briefly.

First off, most of these params are /not/ compatible with versions of UltraFractal below 5.0 because I am a huge fan of layer grouping, especially for masking. 
Secondly, the layers are all over the place. I prefer to make my colours by simply piling 50 different gradients on top of each other. Sorry about that.
Thirdly, my technical skill level in UF is actually quite low. So a master would probably laugh over the way that I've set up my layers, but meh. I tend to prefer simple methods, so once you figure out the chaos that is my workflow you will have no issue picking out individual techniques.

The reason as to why my parameters are all saved as a bunch of .txt's is twofold. First off, many have complained that they have trouble opening .UPR files from my computer and secondly, it's pretty gosh damn hard to hide anything malicious in a blanktext file. 

Also, if you want to toss me a bone, you are free to look at my amazon wishlist or maybe buy something from my RedBubble Store. I'm piecing together a collection of decade old books that are impossible to find in my country. https://www.amazon.co.uk/gp/registry/wishlist/ref=cm_wl_upd_succ_mng

Well, that's about it. You can read the rest on the deviation page itself.

Thank you all. I really mean it. 


-Misha




http://www.OutsideFate.deviantART.com
http://www.RedBubble.com/people/OutsideFate